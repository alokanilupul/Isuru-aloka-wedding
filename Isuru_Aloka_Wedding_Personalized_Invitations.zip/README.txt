ISURU & ALOKA WEDDING WEBSITE

Files:
- index.html: public wedding website with live countdown, personalized guest greeting and WhatsApp RSVP button.
- guest-manager.html: enter one guest name per line and generate a unique link for each guest; download links as CSV.
- images/: website photos.

To publish: upload this ZIP to Netlify Drop (https://app.netlify.com/drop). After publishing, open guest-manager.html on your public Netlify site, enter names and generate links. Send each guest their own link. RSVP opens WhatsApp to +94 76 916 7271 with a pre-filled message; the guest must tap Send.
